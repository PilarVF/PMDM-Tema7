package com.example.proyectosqlite1

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context

class DataManager(context: Context) {
    /* Creamos una instancia de DatabaseHelper y le añadimos el contexto; es decir,
    acceso a recursos, base de datos, etc. */
    private val dbHelper = DatabaseHelper(context)

    fun addUser(nombre: String, contrasenia: String) {
        val db = dbHelper.writableDatabase // Usamos el método para escribir en la BBDD.

        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_NAME, nombre)
            put(DatabaseHelper.COLUMN_NAME2, contrasenia)
        }

        db.insert(DatabaseHelper.TABLE_DATOS, null, values)
        db.close()
    }

    // rawQuery crea una consulta y la devuelve en un cursor:
    @SuppressLint("Range")
    fun getAllUsers(context: Context): String {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_DATOS}", null)
        val datos = StringBuilder()

        while (cursor.moveToNext()) {
            val name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME))
            val password = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME2))
            datos.append("Nombre: $name, Contraseña: $password\n")
        }

        cursor.close()
        db.close()

        if (datos.isEmpty()) {
            return "No hay nombres ni contraseñas en la base de datos"
        }

        return datos.toString()
    }
}