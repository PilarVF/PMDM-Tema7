package com.example.proyectosqlite1

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var dataManager: DataManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataManager = DataManager(this)
        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnAgregar = findViewById<Button>(R.id.btnAgregar)
        val btnMostrar = findViewById<Button>(R.id.btnMostrar)
        val tvMuestraDatos = findViewById<TextView>(R.id.tvMuestraDatos)

        btnAgregar.setOnClickListener {
            val nombre = etNombre.text.toString()
            val password = etPassword.text.toString()
            dataManager.addUser(nombre, password)
            Toast.makeText(this, "Se agregó a la base de datos: $nombre, $password",
                Toast.LENGTH_SHORT).show()
            etNombre.text.clear() // Limpiamos el componente EdiText.
            etPassword.text.clear()
        }

        // Muestra todos los datos:
        btnMostrar.setOnClickListener {
            // Estamos instanciando la clase DataManager:
            val datos = dataManager.getAllUsers(this)
            tvMuestraDatos.text = datos // Nos muestra los nombres y contraseñas que hay en la tabla.
        }
    }
}