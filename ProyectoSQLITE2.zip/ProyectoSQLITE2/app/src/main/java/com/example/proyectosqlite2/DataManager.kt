package com.example.proyectosqlite2

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context

class DataManager(context: Context) {
    /* Creamos una instancia de DatabaseHelper y le añadimos el contexto; es decir,
    acceso a recursos, base de datos, etc. */
    private val dbHelper = DatabaseHelper(context)

    fun addAlumno(nombre: String, apellidos: String, dni: String, edad: Int, curso:String) {
        val db = dbHelper.writableDatabase // Usamos el método para escribir en la BBDD.

        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_NAME, nombre)
            put(DatabaseHelper.COLUMN_NAME2, apellidos)
            put(DatabaseHelper.COLUMN_NAME3, dni)
            put(DatabaseHelper.COLUMN_NAME4, edad)
            put(DatabaseHelper.COLUMN_NAME5, curso)
        }

        db.insert(DatabaseHelper.TABLE_ALUMNOS, null, values)
        db.close()
    }

    // rawQuery crea una consulta y la devuelve en un cursor:
    @SuppressLint("Range")
    fun getAllAlumnos(context: Context): String {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_ALUMNOS}", null)
        val datos = StringBuilder()

        while (cursor.moveToNext()) {
            val id = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID))
            val nombre = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME))
            val apellidos = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME2))
            val dni = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME3))
            val edad = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME4))
            val curso = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME5))
            datos.append("ID Alumno: $id, Nombre: $nombre, Apellidos: $apellidos, DNI: $dni, Edad: $edad, " +
                    "Curso: $curso\n")
        }

        cursor.close()
        db.close()

        if (datos.isEmpty()) {
            return "No hay registros en la base de datos"
        }

        return datos.toString()
    }
}