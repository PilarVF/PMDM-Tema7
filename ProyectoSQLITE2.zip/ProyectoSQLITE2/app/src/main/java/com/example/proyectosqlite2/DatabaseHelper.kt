package com.example.proyectosqlite2

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context,
    DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "alumnos.db"
        const val TABLE_ALUMNOS = "datos_alumnos"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "nombre"
        const val COLUMN_SURNAMES = "apellidos"
        const val COLUMN_DNI = "dni"
        const val COLUMN_AGE = "edad"
        const val COLUMN_COURSE = "curso"
    }

    // Creamos el método onCreate que crea la tabla:
    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE = "CREATE TABLE $TABLE_ALUMNOS ($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_NAME TEXT, $COLUMN_SURNAMES TEXT, $COLUMN_DNI TEXT, $COLUMN_AGE TEXT, " +
                "$COLUMN_COURSE TEXT)"
        db.execSQL(CREATE_TABLE)
    }

    // Creamos el método que permite eliminar la table y volver a crearla:
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ALUMNOS")
        onCreate(db)
    }
}