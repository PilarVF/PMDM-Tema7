package com.example.proyectosqlite2

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context,
    DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "alumnos.db"
        const val TABLE_ALUMNOS = "datos_alumnos"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "nombre"
        const val COLUMN_NAME2 = "apellidos"
        const val COLUMN_NAME3 = "dni"
        const val COLUMN_NAME4 = "edad"
        const val COLUMN_NAME5 = "curso"
    }

    // Creamos el método onCreate que crea la tabla:
    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE = "CREATE TABLE $TABLE_ALUMNOS ($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_NAME TEXT, $COLUMN_NAME2 TEXT, $COLUMN_NAME3 TEXT, $COLUMN_NAME4 TEXT, " +
                "$COLUMN_NAME5 TEXT)"
        db.execSQL(CREATE_TABLE)
    }

    // Creamos el método que permite eliminar la table y volver a crearla:
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ALUMNOS")
        onCreate(db)
    }
}