package com.example.proyectosqlite3_reto

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.example.proyectosqlite3_reto.DatabaseHelper.Companion.COLUMN_ID
import com.example.proyectosqlite3_reto.DatabaseHelper.Companion.TABLE_PATIENTS

class MainActivity : AppCompatActivity() {
    private lateinit var dataManager: DataManager
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var db: SQLiteDatabase

    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dataManager = DataManager(this)
        dbHelper = DatabaseHelper(this)
        db = dbHelper.readableDatabase

        val etName = findViewById<EditText>(R.id.etName)
        val etSurnames = findViewById<EditText>(R.id.etSurnames)
        val etDNI = findViewById<EditText>(R.id.etDNI)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etAddress = findViewById<EditText>(R.id.etAddress)
        val etPhone = findViewById<EditText>(R.id.etPhone)
        val etRecord = findViewById<EditText>(R.id.etRecord)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val btnShowAll = findViewById<Button>(R.id.btnShowAll)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnAdd.setOnClickListener {
            val nombre = etName.text.toString()
            val apellidos = etSurnames.text.toString()
            val dni = etDNI.text.toString()
            val edad = etAge.text.toString().toIntOrNull()
            val direccion = etAddress.text.toString()
            val telefono = etPhone.text.toString()
            val historial = etRecord.text.toString()

            dataManager.addPaciente(nombre, apellidos, dni, edad, direccion, telefono, historial)

            Toast.makeText(this, "Paciente agregado correctamente.", Toast.LENGTH_SHORT).show()

            // Limpiar los campos de entrada después de agregar el paciente:
            etName.text.clear()
            etSurnames.text.clear()
            etDNI.text.clear()
            etAge.text.clear()
            etAddress.text.clear()
            etPhone.text.clear()
            etRecord.text.clear()
        }

        btnUpdate.setOnClickListener {
            val listaIdsPacientes = obtenerListaIdsPacientes()

            val nuevoNombre = etName.text.toString()
            val nuevosApellidos = etSurnames.text.toString()

            if (listaIdsPacientes.isNotEmpty()) {
                val idsArray = listaIdsPacientes.map { it.toString() }.toTypedArray()
                val builder = AlertDialog.Builder(this)

                builder.setTitle("Selecciona un ID de paciente:")
                builder.setItems(idsArray) { _, which ->
                    val idPacienteSeleccionado = listaIdsPacientes[which]
                    val rowsAffected = dataManager.updatePaciente(idPacienteSeleccionado,
                        nuevoNombre, nuevosApellidos)

                    if (rowsAffected > 0) {
                        Toast.makeText(this, "Paciente actualizado correctamente.",
                            Toast.LENGTH_SHORT).show()

                    } else {
                        Toast.makeText(this, "Error al actualizar el paciente.",
                            Toast.LENGTH_SHORT).show()
                    }
                }

                builder.show()

            } else {
                Toast.makeText(this, "No hay pacientes disponibles para actualizar.",
                    Toast.LENGTH_SHORT).show()
            }

            etName.text.clear()
            etSurnames.text.clear()
        }

        btnDelete.setOnClickListener {
            val listaIdsPacientes = obtenerListaIdsPacientes()

            if (listaIdsPacientes.isNotEmpty()) {
                val idsArray = listaIdsPacientes.map { it.toString() }.toTypedArray()
                val builder = AlertDialog.Builder(this)

                builder.setTitle("Selecciona un ID de paciente a eliminar:")
                builder.setItems(idsArray) { _, which ->
                    val idPacienteSeleccionado = listaIdsPacientes[which]
                    val rowsAffected = dataManager.deletePaciente(idPacienteSeleccionado)

                    if (rowsAffected > 0) {
                        Toast.makeText(this, "Paciente eliminado correctamente.",
                            Toast.LENGTH_SHORT).show()

                    } else {
                        Toast.makeText(this, "Error al eliminar el paciente.",
                            Toast.LENGTH_SHORT).show()
                    }
                }

                builder.show()

            } else {
                Toast.makeText(this, "No hay pacientes disponibles para eliminar.",
                    Toast.LENGTH_SHORT).show()
            }
        }

        btnShowAll.setOnClickListener {
            val datos = dataManager.getAllPacientes(this)

            tvResult.text = datos
        }
    }

    fun obtenerListaIdsPacientes(): List<Int> {
        val listaIds = mutableListOf<Int>()
        val db = dbHelper.readableDatabase // Abre la base de datos

        val cursor = db.rawQuery("SELECT $COLUMN_ID FROM $TABLE_PATIENTS", null)

        while (cursor.moveToNext()) {
            val idIndex = cursor.getColumnIndex(COLUMN_ID)

            if (idIndex != -1) {
                val id = cursor.getInt(idIndex)
                listaIds.add(id)

            } else {
                Log.d("DatabaseHelper", "No se pudo obtener el ID: Columna no encontrada.")
            }
        }

        cursor.close()

        return listaIds
    }
}