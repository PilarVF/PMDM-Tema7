package com.example.proyectosqlite3_reto

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context

class DataManager(context: Context) {
    private val dbHelper: DatabaseHelper = DatabaseHelper(context)

    fun addPaciente(
        nombre: String, apellidos: String, dni:String, edad: Int?, direccion: String,
        telefono: String, historial: String) {
        val db = dbHelper.writableDatabase // Usamos el método para escribir en la BBDD.

        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_NAME, nombre)
            put(DatabaseHelper.COLUMN_SURNAMES, apellidos)
            put(DatabaseHelper.COLUMN_DNI, dni)
            put(DatabaseHelper.COLUMN_AGE, edad)
            put(DatabaseHelper.COLUMN_ADDRESS, direccion)
            put(DatabaseHelper.COLUMN_PHONE, telefono)
            put(DatabaseHelper.COLUMN_RECORD, historial)
        }

        db.insert(DatabaseHelper.TABLE_PATIENTS, null, values)
        db.close()
    }

    @SuppressLint("Range")
    fun getAllPacientes(context: Context): String {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_PATIENTS}", null)
        val datos = StringBuilder()

        while (cursor.moveToNext()) {
            val nombre = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME))
            val apellidos = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_SURNAMES))
            val dni = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DNI))
            val edad = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_AGE))
            val direccion = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_ADDRESS))
            val telefono = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PHONE))
            val historial = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_RECORD))

            datos.append("Nombre: $nombre, Apellidos: $apellidos, DNI: $dni, Edad: $edad, " +
                    "Dirección: $direccion, Teléfono: $telefono, Historial: $historial\n")
        }

        cursor.close()
        db.close()

        if (datos.isEmpty()) {
            return "No hay registros en la base de datos."
        }

        return datos.toString()
    }

    fun updatePaciente(id: Int, nombre: String, apellidos: String): Int {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(DatabaseHelper.COLUMN_NAME, nombre)
            put(DatabaseHelper.COLUMN_SURNAMES, apellidos)
        }

        val rowsAffected = db.update(
            DatabaseHelper.TABLE_PATIENTS, values, "${DatabaseHelper.COLUMN_ID} = ?",
            arrayOf(id.toString()))

        db.close()

        return rowsAffected
    }

    fun deletePaciente(id: Int): Int {
        val db = dbHelper.writableDatabase

        val rowsDeleted = db.delete(DatabaseHelper.TABLE_PATIENTS, "${DatabaseHelper.COLUMN_ID} = ?",
            arrayOf(id.toString()))

        db.close()

        return rowsDeleted
    }
}