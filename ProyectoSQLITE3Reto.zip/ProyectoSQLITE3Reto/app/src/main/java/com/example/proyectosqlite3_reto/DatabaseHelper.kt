package com.example.proyectosqlite3_reto

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null,
    DATABASE_VERSION) {
    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "HospitalDB"
        const val TABLE_PATIENTS = "pacientes"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "nombre"
        const val COLUMN_SURNAMES = "apellidos"
        const val COLUMN_DNI = "dni"
        const val COLUMN_AGE = "edad"
        const val COLUMN_ADDRESS = "direccion"
        const val COLUMN_PHONE = "telefono"
        const val COLUMN_RECORD = "historial"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE = ("CREATE TABLE $TABLE_PATIENTS ($COLUMN_ID INTEGER PRIMARY KEY, " +
                "$COLUMN_NAME TEXT, $COLUMN_SURNAMES TEXT, $COLUMN_DNI TEXT, $COLUMN_AGE INTEGER, " +
                "$COLUMN_ADDRESS TEXT, $COLUMN_PHONE TEXT, $COLUMN_RECORD TEXT)")

        db.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PATIENTS")

        onCreate(db)
    }
}