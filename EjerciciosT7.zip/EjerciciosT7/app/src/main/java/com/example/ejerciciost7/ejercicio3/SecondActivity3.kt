package com.example.ejerciciost7.ejercicio3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.ejerciciost7.R

class SecondActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second3)

        val tvFileContent: TextView = findViewById(R.id.tvFileContent)

        // Obtener el contenido del archivo desde el intent:
        val fileContent = intent.getStringExtra("fileContent")
        tvFileContent.text = fileContent
    }
}