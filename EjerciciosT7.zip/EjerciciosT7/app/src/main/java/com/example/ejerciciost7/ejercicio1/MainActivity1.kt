package com.example.ejerciciost7.ejercicio1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.example.ejerciciost7.R
import java.io.OutputStreamWriter

class MainActivity1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main1)

        val btnCrearArchivo: Button = findViewById(R.id.btnCrearArchivo)

        btnCrearArchivo.setOnClickListener {
            crearArchivo()
        }
    }

    private fun crearArchivo() {
        try {
            val fileName = "Alberto el grande"
            val fileContent = "Alberto imperator"

            // Abrir un OutputStreamWriter en el modo privado (solo accesible por esta aplicación):
            var osw: OutputStreamWriter = OutputStreamWriter(openFileOutput(fileName, Context.MODE_PRIVATE))

            // Escribir el contenido en el archivo:
            osw.write(fileContent)

            // Limpiar y cerrar el OutputStreamWriter:
            osw.flush() // Limpiamos.
            osw.close() // Cerramos.

            Log.d("Éxito", "¡Archivo creado con éxito!")

        } catch (e: Exception) {
            Log.d("Error", "Error al usar el OutputStreamWriter: " + e.message)
        }
    }
}