package com.example.ejerciciost7.ejercicio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import com.example.ejerciciost7.R
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val btnReadFile: Button = findViewById(R.id.btnReadFile)

        btnReadFile.setOnClickListener {
            readFile()
        }
    }

    private fun readFile() {
        try {
            val fileName = "Alberto el grande"

            val br = BufferedReader(InputStreamReader(openFileInput(fileName)))
            val text = br.readLine()
            br.close()

            // Iniciar una nueva actividad para mostrar el contenido del archivo en un TextView:
            val intent = Intent(this, SecondActivity3::class.java)
            intent.putExtra("fileContent", text)
            startActivity(intent)

        } catch (e: Exception) {
            Log.e("Error", "Error al leer el archivo: " + e.message)
        }
    }
}