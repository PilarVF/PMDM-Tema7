package com.example.ejerciciost7.reto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import com.example.ejerciciost7.R
import java.io.BufferedReader
import java.io.InputStreamReader

class RetoActivity : AppCompatActivity() {
    private lateinit var tvContent: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reto)

        val btnLeerArch: Button = findViewById(R.id.btnLeerArch)
        tvContent = findViewById(R.id.tvContent)

        btnLeerArch.setOnClickListener {
            leerArchivo()
        }
    }

    private fun leerArchivo() {
        try {
            val nombreArch = "Alberto el grande"

            val br = BufferedReader(InputStreamReader(openFileInput(nombreArch)))
            val textoArch = br.readLine()
            br.close()

            tvContent.text = textoArch

        } catch (e: Exception) {
            Log.e("Error", "Error al leer el archivo: " + e.message)
        }
    }
}